<div class="mt-8 text-center bg-gray-800 text-white p-2 fixed bottom-00 w-full text-white font-bold" style="background-color: darkslateblue;position:fixed;bottom:0;width:100%;color:white">
   <span>PARCEL BUDDY © 2024 Copyright</span>
</div>
<script src="js/bootstrap.js"></script>
</body>
</html>